package com.flasher.app;

import android.Manifest;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends Activity {

    private static final int MATCH = ViewGroup.LayoutParams.MATCH_PARENT;
    private static final int WRAP = ViewGroup.LayoutParams.WRAP_CONTENT;

    private static final int COLOR_BG = 0xFF0E1014;
    private static final int COLOR_CARD = 0xFF171A21;
    private static final int COLOR_FIELD = 0xFF222733;
    private static final int COLOR_TEXT = 0xFFEDEFF3;
    private static final int COLOR_MUTED = 0xFF8A90A0;
    private static final int COLOR_ACCENT = 0xFFFFC233;
    private static final int COLOR_DANGER = 0xFFFF5A5F;
    private static final int COLOR_ON_ACCENT = 0xFF1A1400;

    private SharedPreferences prefs;
    private final Handler ui = new Handler(Looper.getMainLooper());

    private LampView lamp;
    private TextView statusText;
    private TextView tabFlasher;
    private TextView tabRhythm;
    private Button startBtn;
    private LinearLayout panelFlasher;
    private LinearLayout panelRhythm;

    // Flasher tab
    private TimeRow onRow;
    private TimeRow offRow;
    private TextView rateText;
    private EditText stopFlasherEdit;

    // Rhythm tab
    private EditText patternEdit;
    private EditText morseEdit;
    private EditText unitEdit;
    private EditText stopRhythmEdit;
    private CheckBox loopCheck;
    private Button recordBtn;
    private TextView recordPad;
    private TextView recordInfo;
    private boolean recording;
    private boolean recPressed;
    private long recLast;
    private final ArrayList<Long> recSteps = new ArrayList<>();

    private boolean flashAvailable;
    private boolean showingRhythm;
    private Boolean shownRunning;

    // ------------------------------------------------------------------ lifecycle

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("flasher", MODE_PRIVATE);
        flashAvailable = getPackageManager().hasSystemFeature(PackageManager.FEATURE_CAMERA_FLASH);
        setContentView(buildUi());
        loadPrefs();
        selectTab(prefs.getBoolean("rhythmTab", false));
    }

    @Override
    protected void onStart() {
        super.onStart();
        IntentFilter filter = new IntentFilter(FlashService.ACTION_STATE);
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(stateReceiver, filter, Context.RECEIVER_NOT_EXPORTED);
        } else {
            registerReceiver(stateReceiver, filter);
        }
    }

    @Override
    protected void onStop() {
        unregisterReceiver(stateReceiver);
        super.onStop();
    }

    @Override
    protected void onResume() {
        super.onResume();
        shownRunning = null;
        ui.post(tick);
    }

    @Override
    protected void onPause() {
        ui.removeCallbacks(tick);
        ui.removeCallbacks(liveRunnable);
        savePrefs();
        super.onPause();
    }

    private final BroadcastReceiver stateReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String err = intent.getStringExtra(FlashService.EXTRA_ERROR);
            if (err != null) {
                toast(err);
            }
            refreshStatus();
        }
    };

    /** ~30 times a second: mirror the torch on the on-screen lamp and keep the button in sync. */
    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            lamp.setLit(recPressed || (FlashService.running && FlashService.torchOn));
            refreshStatus();
            ui.postDelayed(this, 30);
        }
    };

    /** Applies slider changes to a run that is already going (debounced). */
    private final Runnable liveRunnable = new Runnable() {
        @Override
        public void run() {
            if (!FlashService.running || showingRhythm) {
                return;
            }
            try {
                sendStart(flasherSteps(), true, secondsOf(stopFlasherEdit) * 1000L);
            } catch (IllegalArgumentException ignored) {
                // a half-typed value; the next change will try again
            }
        }
    };

    private void scheduleLive() {
        if (FlashService.running && !showingRhythm) {
            ui.removeCallbacks(liveRunnable);
            ui.postDelayed(liveRunnable, 150);
        }
    }

    // ------------------------------------------------------------------ start / stop

    private void onStartStop() {
        if (FlashService.running) {
            Intent stop = new Intent(this, FlashService.class);
            stop.setAction(FlashService.ACTION_STOP);
            startService(stop);
            return;
        }
        if (!flashAvailable) {
            toast("This phone has no flashlight");
            return;
        }
        long[] steps;
        boolean loop;
        long limitMs;
        try {
            if (!showingRhythm) {
                steps = flasherSteps();
                loop = true;
                limitMs = secondsOf(stopFlasherEdit) * 1000L;
            } else {
                steps = RhythmParser.parse(patternEdit.getText().toString());
                loop = loopCheck.isChecked();
                limitMs = secondsOf(stopRhythmEdit) * 1000L;
            }
        } catch (IllegalArgumentException e) {
            toast(e.getMessage());
            return;
        }
        sendStart(steps, loop, limitMs);
        askNotificationPermissionOnce();
    }

    private long[] flasherSteps() {
        return new long[]{onRow.value("ON"), offRow.value("OFF")};
    }

    private void sendStart(long[] steps, boolean loop, long limitMs) {
        Intent i = new Intent(this, FlashService.class);
        i.setAction(FlashService.ACTION_START);
        i.putExtra(FlashService.EXTRA_STEPS, steps);
        i.putExtra(FlashService.EXTRA_LOOP, loop);
        i.putExtra(FlashService.EXTRA_LIMIT_MS, limitMs);
        startForegroundService(i);
    }

    private long secondsOf(EditText e) {
        try {
            long v = RhythmParser.parseNumber(e.getText().toString());
            return Math.max(0L, Math.min(v, 604800L));
        } catch (IllegalArgumentException ex) {
            return 0L;
        }
    }

    private void askNotificationPermissionOnce() {
        if (Build.VERSION.SDK_INT >= 33
                && !prefs.getBoolean("notifAsked", false)
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            prefs.edit().putBoolean("notifAsked", true).apply();
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1);
        }
    }

    private void refreshStatus() {
        boolean r = FlashService.running;
        if (shownRunning != null && shownRunning == r) {
            return;
        }
        shownRunning = r;
        startBtn.setText(r ? "STOP" : "START");
        startBtn.setTextColor(r ? 0xFFFFFFFF : COLOR_ON_ACCENT);
        startBtn.setBackground(round(r ? COLOR_DANGER : COLOR_ACCENT, 16));
        if (!flashAvailable) {
            statusText.setText("No flashlight found on this phone");
        } else {
            statusText.setText(r ? "Flashing…" : "Ready");
        }
    }

    // ------------------------------------------------------------------ preferences

    private void loadPrefs() {
        onRow.set(prefs.getLong("on", 300L));
        offRow.set(prefs.getLong("off", 300L));
        stopFlasherEdit.setText(prefs.getString("stopF", "0"));
        patternEdit.setText(prefs.getString("pattern", RhythmParser.PRESETS[0][1]));
        loopCheck.setChecked(prefs.getBoolean("loop", true));
        stopRhythmEdit.setText(prefs.getString("stopR", "0"));
        unitEdit.setText(prefs.getString("unit", "150"));
        morseEdit.setText(prefs.getString("morse", "SOS"));
    }

    private void savePrefs() {
        prefs.edit()
                .putLong("on", onRow.last)
                .putLong("off", offRow.last)
                .putString("stopF", stopFlasherEdit.getText().toString())
                .putString("pattern", patternEdit.getText().toString())
                .putBoolean("loop", loopCheck.isChecked())
                .putString("stopR", stopRhythmEdit.getText().toString())
                .putString("unit", unitEdit.getText().toString())
                .putString("morse", morseEdit.getText().toString())
                .putBoolean("rhythmTab", showingRhythm)
                .apply();
    }

    // ------------------------------------------------------------------ tabs

    private void selectTab(boolean rhythm) {
        showingRhythm = rhythm;
        panelFlasher.setVisibility(rhythm ? View.GONE : View.VISIBLE);
        panelRhythm.setVisibility(rhythm ? View.VISIBLE : View.GONE);
        styleTab(tabFlasher, !rhythm);
        styleTab(tabRhythm, rhythm);
    }

    private void styleTab(TextView t, boolean active) {
        t.setBackground(active ? round(COLOR_ACCENT, 11) : null);
        t.setTextColor(active ? COLOR_ON_ACCENT : COLOR_MUTED);
    }

    private TextView tab(String label, final boolean rhythm) {
        TextView t = text(label, 16, COLOR_MUTED, true);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(8), dp(10), dp(8), dp(10));
        t.setOnClickListener(v -> selectTab(rhythm));
        return t;
    }

    // ------------------------------------------------------------------ UI building

    private View buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(COLOR_BG);

        ScrollView scroll = new ScrollView(this);
        scroll.setVerticalScrollBarEnabled(false);
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(16), dp(8), dp(16), dp(24));
        scroll.addView(content, new ViewGroup.LayoutParams(MATCH, WRAP));
        root.addView(scroll, new LinearLayout.LayoutParams(MATCH, 0, 1f));

        content.addView(text("Flasher", 26, COLOR_TEXT, true));
        content.addView(text("Flashlight strobe with your own timing and rhythms", 14, COLOR_MUTED, false));

        lamp = new LampView(this);
        content.addView(lamp, new LinearLayout.LayoutParams(MATCH, dp(150)));

        statusText = text("Ready", 15, COLOR_MUTED, false);
        statusText.setGravity(Gravity.CENTER);
        content.addView(statusText, new LinearLayout.LayoutParams(MATCH, WRAP));

        LinearLayout tabs = new LinearLayout(this);
        tabs.setOrientation(LinearLayout.HORIZONTAL);
        tabs.setBackground(round(COLOR_CARD, 14));
        tabs.setPadding(dp(4), dp(4), dp(4), dp(4));
        tabFlasher = tab("Flasher", false);
        tabRhythm = tab("Rhythm", true);
        tabs.addView(tabFlasher, new LinearLayout.LayoutParams(0, WRAP, 1f));
        tabs.addView(tabRhythm, new LinearLayout.LayoutParams(0, WRAP, 1f));
        content.addView(tabs, topMargin(12));

        panelFlasher = buildFlasherPanel();
        panelRhythm = buildRhythmPanel();
        content.addView(panelFlasher, new LinearLayout.LayoutParams(MATCH, WRAP));
        content.addView(panelRhythm, new LinearLayout.LayoutParams(MATCH, WRAP));

        TextView warn = text("Warning: fast flashing can trigger seizures in people with photosensitive epilepsy. "
                + "The flashlight can also get warm if it runs for a long time.", 12, COLOR_MUTED, false);
        content.addView(warn, topMargin(16));

        LinearLayout bar = new LinearLayout(this);
        bar.setBackgroundColor(COLOR_BG);
        bar.setPadding(dp(16), dp(10), dp(16), dp(12));
        startBtn = new Button(this);
        startBtn.setAllCaps(false);
        startBtn.setTextSize(20);
        startBtn.setTypeface(Typeface.DEFAULT_BOLD);
        startBtn.setOnClickListener(v -> onStartStop());
        startBtn.setEnabled(flashAvailable);
        bar.addView(startBtn, new LinearLayout.LayoutParams(MATCH, dp(60)));
        root.addView(bar, new LinearLayout.LayoutParams(MATCH, WRAP));

        return root;
    }

    private LinearLayout buildFlasherPanel() {
        LinearLayout p = new LinearLayout(this);
        p.setOrientation(LinearLayout.VERTICAL);

        LinearLayout times = card();
        onRow = new TimeRow("Light ON", 300L);
        offRow = new TimeRow("Light OFF", 300L);
        times.addView(onRow.view);
        times.addView(offRow.view, topMargin(16));
        rateText = text("", 14, COLOR_MUTED, false);
        times.addView(rateText, topMargin(12));
        p.addView(times);
        updateRate();

        LinearLayout presets = card();
        presets.addView(text("Quick presets", 16, COLOR_TEXT, true));
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.addView(chip("Strobe 50/50", v -> setTimes(50, 50)));
        row.addView(chip("Fast 100/100", v -> setTimes(100, 100)));
        row.addView(chip("Blink 500/500", v -> setTimes(500, 500)));
        row.addView(chip("Slow 1000/1000", v -> setTimes(1000, 1000)));
        row.addView(chip("Beacon 100/1900", v -> setTimes(100, 1900)));
        presets.addView(hscroll(row), topMargin(10));
        p.addView(presets, topMargin(0));

        LinearLayout stop = card();
        stop.addView(text("Stop automatically after (seconds)", 16, COLOR_TEXT, true));
        stopFlasherEdit = field(InputType.TYPE_CLASS_NUMBER, "0 = run until I press Stop");
        stop.addView(stopFlasherEdit, topMargin(8));
        p.addView(stop);

        return p;
    }

    private LinearLayout buildRhythmPanel() {
        LinearLayout p = new LinearLayout(this);
        p.setOrientation(LinearLayout.VERTICAL);

        // Pattern editor
        LinearLayout pattern = card();
        pattern.addView(text("Your rhythm", 16, COLOR_TEXT, true));
        pattern.addView(text("Times in milliseconds, alternating light ON, OFF, ON, OFF… "
                + "If it ends on ON, a pause is added before it repeats.", 13, COLOR_MUTED, false), topMargin(4));
        patternEdit = field(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE,
                "e.g. 200 100 200 100 600 400");
        patternEdit.setMinLines(3);
        patternEdit.setGravity(Gravity.TOP | Gravity.START);
        pattern.addView(patternEdit, topMargin(10));

        LinearLayout presetRow = new LinearLayout(this);
        presetRow.setOrientation(LinearLayout.HORIZONTAL);
        for (final String[] preset : RhythmParser.PRESETS) {
            presetRow.addView(chip(preset[0], v -> patternEdit.setText(preset[1])));
        }
        pattern.addView(hscroll(presetRow), topMargin(10));

        loopCheck = new CheckBox(this);
        loopCheck.setText("Repeat forever");
        loopCheck.setTextColor(COLOR_TEXT);
        loopCheck.setChecked(true);
        pattern.addView(loopCheck, topMargin(8));

        stopRhythmEdit = field(InputType.TYPE_CLASS_NUMBER, "Stop after … seconds (0 = never)");
        pattern.addView(stopRhythmEdit, topMargin(8));
        p.addView(pattern);

        // Record by tapping
        LinearLayout rec = card();
        rec.addView(text("Record by tapping", 16, COLOR_TEXT, true));
        rec.addView(text("Press Record, then press and hold the pad: the light is on while your finger is down. "
                + "The gaps are recorded too.", 13, COLOR_MUTED, false), topMargin(4));
        recordBtn = pillButton("● Record", v -> toggleRecording());
        rec.addView(recordBtn, topMargin(10));
        recordPad = text("Press Record first", 16, COLOR_MUTED, true);
        recordPad.setGravity(Gravity.CENTER);
        recordPad.setBackground(round(COLOR_FIELD, 18));
        recordPad.setOnTouchListener((v, ev) -> onPadTouch(v, ev));
        rec.addView(recordPad, new LinearLayout.LayoutParams(MATCH, dp(110)));
        ((LinearLayout.LayoutParams) recordPad.getLayoutParams()).topMargin = dp(10);
        recordInfo = text("0 steps", 13, COLOR_MUTED, false);
        rec.addView(recordInfo, topMargin(8));
        p.addView(rec);

        // Morse
        LinearLayout morse = card();
        morse.addView(text("Text to Morse", 16, COLOR_TEXT, true));
        morse.addView(text("Type a word and it becomes a rhythm. Dot length sets the speed.",
                13, COLOR_MUTED, false), topMargin(4));
        LinearLayout morseRow = new LinearLayout(this);
        morseRow.setOrientation(LinearLayout.HORIZONTAL);
        morseEdit = field(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS, "e.g. HELLO");
        unitEdit = field(InputType.TYPE_CLASS_NUMBER, "Dot ms");
        unitEdit.setGravity(Gravity.CENTER);
        morseRow.addView(morseEdit, new LinearLayout.LayoutParams(0, WRAP, 1f));
        LinearLayout.LayoutParams ulp = new LinearLayout.LayoutParams(dp(96), WRAP);
        ulp.leftMargin = dp(8);
        morseRow.addView(unitEdit, ulp);
        morse.addView(morseRow, topMargin(10));
        morse.addView(pillButton("Make rhythm from text", v -> makeMorse()), topMargin(8));
        p.addView(morse);

        return p;
    }

    private void setTimes(long on, long off) {
        onRow.set(on);
        offRow.set(off);
    }

    private void updateRate() {
        if (rateText == null || onRow == null || offRow == null) {
            return;
        }
        double on = onRow.last;
        double off = offRow.last;
        double cycle = on + off;
        double hz = 1000.0 / cycle;
        int duty = (int) Math.round(on * 100.0 / cycle);
        rateText.setText(String.format(Locale.US,
                "%.1f flashes per second · light is on %d%% of the time", hz, duty));
    }

    // ------------------------------------------------------------------ record & morse

    private void toggleRecording() {
        if (!recording) {
            recording = true;
            recSteps.clear();
            recPressed = false;
            recLast = 0L;
            recordBtn.setText("■ Stop recording");
            recordPad.setText("Press and hold here\nto make light");
            recordPad.setTextColor(COLOR_TEXT);
            recordInfo.setText("Recording… 0 steps");
        } else {
            recording = false;
            if (recPressed) {
                recSteps.add(SystemClock.elapsedRealtime() - recLast);
                recPressed = false;
            }
            recordBtn.setText("● Record");
            recordPad.setText("Press Record first");
            recordPad.setTextColor(COLOR_MUTED);
            recordPad.setBackground(round(COLOR_FIELD, 18));
            if (recSteps.isEmpty()) {
                recordInfo.setText("0 steps");
                toast("Nothing recorded");
                return;
            }
            StringBuilder sb = new StringBuilder();
            for (Long v : recSteps) {
                if (sb.length() > 0) {
                    sb.append(' ');
                }
                sb.append(Math.max((long) RhythmParser.MIN_MS, v));
            }
            patternEdit.setText(sb.toString());
            recordInfo.setText(recSteps.size() + " steps saved to your rhythm");
        }
    }

    private boolean onPadTouch(View v, MotionEvent ev) {
        if (!recording) {
            return false;
        }
        long now = SystemClock.elapsedRealtime();
        switch (ev.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                v.getParent().requestDisallowInterceptTouchEvent(true);
                if (!recSteps.isEmpty()) {
                    recSteps.add(now - recLast); // the gap before this press
                }
                recLast = now;
                recPressed = true;
                recordPad.setBackground(round(COLOR_ACCENT, 18));
                return true;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                if (recPressed) {
                    recSteps.add(now - recLast); // how long the light was on
                    recLast = now;
                    recPressed = false;
                }
                recordPad.setBackground(round(COLOR_FIELD, 18));
                recordInfo.setText("Recording… " + recSteps.size() + " steps");
                if (ev.getActionMasked() == MotionEvent.ACTION_UP) {
                    v.performClick();
                }
                return true;
            default:
                return true;
        }
    }

    private void makeMorse() {
        try {
            int unit = (int) Math.min(RhythmParser.parseNumber(unitEdit.getText().toString()), 100000L);
            long[] steps = RhythmParser.fromMorse(morseEdit.getText().toString(), unit);
            patternEdit.setText(RhythmParser.format(steps));
            toast("Rhythm created: " + steps.length + " steps");
        } catch (IllegalArgumentException e) {
            toast(e.getMessage());
        }
    }

    // ------------------------------------------------------------------ view helpers

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_LONG).show();
    }

    private GradientDrawable round(int color, int radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radiusDp));
        return g;
    }

    private TextView text(String s, int sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) {
            t.setTypeface(Typeface.DEFAULT_BOLD);
        }
        return t;
    }

    private LinearLayout.LayoutParams topMargin(int dpValue) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(MATCH, WRAP);
        lp.topMargin = dp(dpValue);
        return lp;
    }

    private LinearLayout card() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setBackground(round(COLOR_CARD, 18));
        l.setPadding(dp(16), dp(14), dp(16), dp(16));
        l.setLayoutParams(topMargin(12));
        return l;
    }

    private EditText field(int inputType, String hint) {
        EditText e = new EditText(this);
        e.setInputType(inputType);
        e.setTextColor(COLOR_TEXT);
        e.setHintTextColor(COLOR_MUTED);
        e.setHint(hint);
        e.setTextSize(16);
        e.setBackground(round(COLOR_FIELD, 10));
        e.setPadding(dp(12), dp(10), dp(12), dp(10));
        return e;
    }

    private TextView chip(String label, View.OnClickListener l) {
        TextView t = text(label, 14, COLOR_TEXT, false);
        t.setBackground(round(COLOR_FIELD, 20));
        t.setPadding(dp(14), dp(8), dp(14), dp(8));
        t.setOnClickListener(l);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(WRAP, WRAP);
        lp.rightMargin = dp(8);
        t.setLayoutParams(lp);
        return t;
    }

    private Button pillButton(String label, View.OnClickListener l) {
        Button b = new Button(this);
        b.setAllCaps(false);
        b.setText(label);
        b.setTextSize(15);
        b.setTextColor(COLOR_ACCENT);
        b.setBackground(round(COLOR_FIELD, 12));
        b.setOnClickListener(l);
        return b;
    }

    private HorizontalScrollView hscroll(View child) {
        HorizontalScrollView h = new HorizontalScrollView(this);
        h.setHorizontalScrollBarEnabled(false);
        h.addView(child);
        return h;
    }

    // ------------------------------------------------------------------ inner classes

    private abstract static class SimpleWatcher implements TextWatcher {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) { }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) { }
    }

    /** A title, a millisecond box and a logarithmic slider, kept in sync. */
    private class TimeRow {
        final LinearLayout view;
        final SeekBar seek;
        final EditText edit;
        long last;
        boolean busy;

        TimeRow(String title, long initial) {
            view = new LinearLayout(MainActivity.this);
            view.setOrientation(LinearLayout.VERTICAL);

            LinearLayout head = new LinearLayout(MainActivity.this);
            head.setOrientation(LinearLayout.HORIZONTAL);
            head.setGravity(Gravity.CENTER_VERTICAL);
            head.addView(text(title, 16, COLOR_TEXT, true), new LinearLayout.LayoutParams(0, WRAP, 1f));
            edit = field(InputType.TYPE_CLASS_NUMBER, "ms");
            edit.setGravity(Gravity.CENTER);
            head.addView(edit, new LinearLayout.LayoutParams(dp(96), WRAP));
            head.addView(text("  ms", 14, COLOR_MUTED, false));
            view.addView(head);

            seek = new SeekBar(MainActivity.this);
            seek.setMax(TimeScale.STEPS);
            view.addView(seek, topMargin(6));

            edit.addTextChangedListener(new SimpleWatcher() {
                @Override
                public void afterTextChanged(Editable s) {
                    if (busy) {
                        return;
                    }
                    try {
                        long v = RhythmParser.parseNumber(s.toString());
                        if (v >= TimeScale.MIN_MS) {
                            last = v;
                            busy = true;
                            seek.setProgress(TimeScale.msToProgress(v));
                            busy = false;
                            changed();
                        }
                    } catch (IllegalArgumentException ignored) {
                        // empty or half-typed: wait for a valid number
                    }
                }
            });

            seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                @Override
                public void onProgressChanged(SeekBar sb, int progress, boolean fromUser) {
                    if (!fromUser || busy) {
                        return;
                    }
                    long v = TimeScale.progressToMs(progress);
                    last = v;
                    busy = true;
                    edit.setText(String.valueOf(v));
                    busy = false;
                    changed();
                }

                @Override
                public void onStartTrackingTouch(SeekBar sb) { }

                @Override
                public void onStopTrackingTouch(SeekBar sb) { }
            });

            set(initial);
        }

        void set(long ms) {
            busy = true;
            last = ms;
            edit.setText(String.valueOf(ms));
            seek.setProgress(TimeScale.msToProgress(ms));
            busy = false;
            changed();
        }

        long value(String name) {
            long v = RhythmParser.parseNumber(edit.getText().toString());
            if (v < TimeScale.MIN_MS) {
                throw new IllegalArgumentException(name + " time must be at least " + TimeScale.MIN_MS + " ms");
            }
            if (v > RhythmParser.MAX_MS) {
                throw new IllegalArgumentException(name + " time is too long");
            }
            return v;
        }

        void changed() {
            updateRate();
            scheduleLive();
        }
    }

    /** The glowing circle that mirrors the real flashlight. */
    private class LampView extends View {
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private RadialGradient glow;
        private boolean lit;

        LampView(Context c) {
            super(c);
        }

        void setLit(boolean value) {
            if (value != lit) {
                lit = value;
                invalidate();
            }
        }

        @Override
        protected void onSizeChanged(int w, int h, int oldw, int oldh) {
            float cx = w / 2f;
            float cy = h / 2f;
            float r = Math.min(cx, cy) * 0.55f;
            glow = new RadialGradient(cx, cy, r * 1.9f,
                    new int[]{0xB0FFC233, 0x00FFC233}, null, Shader.TileMode.CLAMP);
        }

        @Override
        protected void onDraw(Canvas canvas) {
            float cx = getWidth() / 2f;
            float cy = getHeight() / 2f;
            float r = Math.min(cx, cy) * 0.55f;
            if (lit && glow != null) {
                paint.setStyle(Paint.Style.FILL);
                paint.setShader(glow);
                canvas.drawCircle(cx, cy, r * 1.9f, paint);
                paint.setShader(null);
            }
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(lit ? 0xFFFFD866 : 0xFF232834);
            canvas.drawCircle(cx, cy, r, paint);
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(dp(3));
            paint.setColor(lit ? 0xFFFFF0B8 : 0xFF3A4150);
            canvas.drawCircle(cx, cy, r, paint);
        }
    }
}
