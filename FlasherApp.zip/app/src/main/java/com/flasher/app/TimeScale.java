package com.flasher.app;

/**
 * Maps a slider position to a time in milliseconds on a logarithmic scale, so the
 * fast strobe range (20-200 ms) gets as much slider room as the slow range (1-5 s).
 * Pure Java, no Android classes.
 */
public final class TimeScale {

    public static final int MIN_MS = 20;
    public static final int MAX_SLIDER_MS = 5000;
    public static final int STEPS = 1000;

    private TimeScale() { }

    public static int progressToMs(int progress) {
        int p = Math.max(0, Math.min(STEPS, progress));
        double ms = MIN_MS * Math.pow((double) MAX_SLIDER_MS / MIN_MS, p / (double) STEPS);
        return (int) niceRound(ms);
    }

    public static int msToProgress(long ms) {
        double clamped = Math.max(MIN_MS, Math.min(MAX_SLIDER_MS, ms));
        double p = Math.log(clamped / MIN_MS) / Math.log((double) MAX_SLIDER_MS / MIN_MS);
        return (int) Math.round(p * STEPS);
    }

    static long niceRound(double ms) {
        long r;
        if (ms < 100) {
            r = Math.round(ms / 5.0) * 5;
        } else if (ms < 1000) {
            r = Math.round(ms / 10.0) * 10;
        } else {
            r = Math.round(ms / 50.0) * 50;
        }
        return Math.max(MIN_MS, Math.min(MAX_SLIDER_MS, r));
    }
}
