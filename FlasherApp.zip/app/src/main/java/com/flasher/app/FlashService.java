package com.flasher.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.drawable.Icon;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraManager;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;
import android.os.SystemClock;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

/**
 * Runs the flashing on a background thread inside a foreground service, so it keeps
 * going with the screen off or the app closed. Uses CameraManager.setTorchMode, which
 * needs no camera permission.
 */
public class FlashService extends Service {

    public static final String ACTION_START = "com.flasher.app.START";
    public static final String ACTION_STOP = "com.flasher.app.STOP";
    public static final String ACTION_STATE = "com.flasher.app.STATE";
    public static final String EXTRA_STEPS = "steps";
    public static final String EXTRA_LOOP = "loop";
    public static final String EXTRA_LIMIT_MS = "limit_ms";
    public static final String EXTRA_RUNNING = "running";
    public static final String EXTRA_ERROR = "error";

    private static final String CHANNEL_ID = "flasher";
    private static final int NOTIFICATION_ID = 1;

    /** Read by the UI to show state and to light the on-screen lamp. */
    public static volatile boolean running = false;
    public static volatile boolean torchOn = false;

    private final Object lock = new Object();
    private Thread worker;
    private CountDownLatch stopLatch;
    private int generation;

    private CameraManager cameraManager;
    private String cameraId;
    private PowerManager.WakeLock wakeLock;

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent != null ? intent.getAction() : null;
        if (ACTION_START.equals(action)) {
            // startForegroundService() requires us to call startForeground() promptly.
            enterForeground();
            long[] steps = intent.getLongArrayExtra(EXTRA_STEPS);
            boolean loop = intent.getBooleanExtra(EXTRA_LOOP, true);
            long limitMs = intent.getLongExtra(EXTRA_LIMIT_MS, 0L);
            if (steps == null || steps.length == 0) {
                finishRun("Nothing to flash");
            } else {
                beginRun(steps, loop, limitMs);
            }
        } else {
            stopWorker();
            setTorch(false);
            finishRun(null);
        }
        return START_NOT_STICKY;
    }

    @Override
    public void onDestroy() {
        stopWorker();
        setTorch(false);
        torchOn = false;
        running = false;
        releaseWakeLock();
        super.onDestroy();
    }

    // ---------------------------------------------------------------- run control

    private void beginRun(long[] steps, boolean loop, long limitMs) {
        stopWorker(); // replaces any run that is already going (live slider changes)
        if (!initTorch()) {
            finishRun("This phone has no usable flashlight");
            return;
        }
        acquireWakeLock();
        running = true;
        publish(true, null);
        synchronized (lock) {
            final int myGen = ++generation;
            final CountDownLatch latch = new CountDownLatch(1);
            stopLatch = latch;
            worker = new Thread(() -> runLoop(steps, loop, limitMs, latch, myGen), "flash-worker");
            worker.start();
        }
    }

    private void stopWorker() {
        Thread t;
        CountDownLatch l;
        synchronized (lock) {
            t = worker;
            l = stopLatch;
            worker = null;
            stopLatch = null;
            generation++;
        }
        if (l != null) {
            l.countDown();
        }
        if (t != null && t != Thread.currentThread()) {
            try {
                t.join(1500);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }
    }

    private void finishRun(String error) {
        running = false;
        torchOn = false;
        releaseWakeLock();
        publish(false, error);
        stopForeground(STOP_FOREGROUND_REMOVE);
        stopSelf();
    }

    private void runLoop(long[] steps, boolean loop, long limitMs, CountDownLatch latch, int myGen) {
        String error = null;
        long start = SystemClock.elapsedRealtime();
        long next = start;
        int failures = 0;
        try {
            outer:
            do {
                for (int i = 0; i < steps.length; i++) {
                    boolean on = (i % 2 == 0);
                    if (setTorch(on)) {
                        failures = 0;
                    } else if (++failures >= 8) {
                        error = "Couldn't reach the flashlight. Another app may be using the camera.";
                        break outer;
                    }
                    long now = SystemClock.elapsedRealtime();
                    if (now - next > 250) {
                        next = now; // fell far behind: resync instead of bursting to catch up
                    }
                    next += steps[i];
                    long deadline = limitMs > 0 ? Math.min(next, start + limitMs) : next;
                    long wait = deadline - SystemClock.elapsedRealtime();
                    if (wait > 0 && awaitStop(latch, wait)) {
                        break outer;
                    }
                    if (limitMs > 0 && SystemClock.elapsedRealtime() >= start + limitMs) {
                        break outer;
                    }
                }
            } while (loop);
        } catch (RuntimeException e) {
            error = "Flashing stopped unexpectedly";
        } finally {
            setTorch(false);
            torchOn = false;
            boolean current;
            synchronized (lock) {
                current = (generation == myGen);
                if (current) {
                    worker = null;
                    stopLatch = null;
                }
            }
            if (current) {
                finishRun(error);
            }
        }
    }

    private static boolean awaitStop(CountDownLatch latch, long ms) {
        try {
            return latch.await(ms, TimeUnit.MILLISECONDS);
        } catch (InterruptedException e) {
            return true;
        }
    }

    // ---------------------------------------------------------------- torch

    private boolean initTorch() {
        if (cameraId != null) {
            return true;
        }
        try {
            cameraManager = getSystemService(CameraManager.class);
            if (cameraManager == null) {
                return false;
            }
            String fallback = null;
            for (String id : cameraManager.getCameraIdList()) {
                CameraCharacteristics c = cameraManager.getCameraCharacteristics(id);
                Boolean flash = c.get(CameraCharacteristics.FLASH_INFO_AVAILABLE);
                if (flash == null || !flash) {
                    continue;
                }
                Integer facing = c.get(CameraCharacteristics.LENS_FACING);
                if (facing != null && facing == CameraCharacteristics.LENS_FACING_BACK) {
                    cameraId = id;
                    return true;
                }
                if (fallback == null) {
                    fallback = id;
                }
            }
            cameraId = fallback;
            return cameraId != null;
        } catch (CameraAccessException e) {
            return false;
        }
    }

    private boolean setTorch(boolean on) {
        if (cameraManager == null || cameraId == null) {
            return false;
        }
        try {
            cameraManager.setTorchMode(cameraId, on);
            torchOn = on;
            return true;
        } catch (CameraAccessException | IllegalArgumentException e) {
            return false;
        }
    }

    // ---------------------------------------------------------------- plumbing

    private void acquireWakeLock() {
        if (wakeLock == null) {
            PowerManager pm = getSystemService(PowerManager.class);
            if (pm == null) {
                return;
            }
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "flasher:run");
            wakeLock.setReferenceCounted(false);
        }
        if (!wakeLock.isHeld()) {
            wakeLock.acquire(12L * 60L * 60L * 1000L);
        }
    }

    private void releaseWakeLock() {
        if (wakeLock != null && wakeLock.isHeld()) {
            wakeLock.release();
        }
    }

    private void publish(boolean isRunning, String error) {
        Intent i = new Intent(ACTION_STATE);
        i.setPackage(getPackageName());
        i.putExtra(EXTRA_RUNNING, isRunning);
        if (error != null) {
            i.putExtra(EXTRA_ERROR, error);
        }
        sendBroadcast(i);
    }

    private void enterForeground() {
        NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID, "Flasher", NotificationManager.IMPORTANCE_LOW);
        NotificationManager nm = getSystemService(NotificationManager.class);
        if (nm != null) {
            nm.createNotificationChannel(channel);
        }
        Notification n = buildNotification();
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIFICATION_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        } else {
            startForeground(NOTIFICATION_ID, n);
        }
    }

    private Notification buildNotification() {
        Intent open = new Intent(this, MainActivity.class);
        open.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent openPi = PendingIntent.getActivity(
                this, 0, open, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);

        Intent stop = new Intent(this, FlashService.class);
        stop.setAction(ACTION_STOP);
        PendingIntent stopPi = PendingIntent.getService(
                this, 1, stop, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);

        Notification.Action stopAction = new Notification.Action.Builder(
                Icon.createWithResource(this, R.drawable.ic_flash), "Stop", stopPi).build();

        return new Notification.Builder(this, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_flash)
                .setContentTitle("Flasher is running")
                .setContentText("Tap to open, or press Stop")
                .setContentIntent(openPi)
                .setOngoing(true)
                .addAction(stopAction)
                .build();
    }
}
