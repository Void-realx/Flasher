package com.flasher.app;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Turns rhythm text such as "200 100 200 100 600 400" into a step list and back.
 * A rhythm is a list of durations in milliseconds that alternate ON, OFF, ON, OFF, ...
 * Pure Java, no Android classes.
 */
public final class RhythmParser {

    public static final int MIN_MS = 20;
    public static final long MAX_MS = 3_600_000L;
    public static final int MAX_STEPS = 2000;

    /** {name, pattern} pairs shown as preset chips. */
    public static final String[][] PRESETS = {
        {"SOS", "200 200 200 200 200 600 600 200 600 200 600 600 200 200 200 200 200 1400"},
        {"Heartbeat", "120 120 120 800"},
        {"Burst", "40 60 40 60 40 60 40 60 40 400"},
        {"Double tap", "100 100 100 700"},
        {"Disco", "100 100 100 100 300 100 100 100 100 100 300 300"},
    };

    private static final String[] LETTERS = {
        ".-", "-...", "-.-.", "-..", ".", "..-.", "--.", "....", "..", ".---", "-.-", ".-..", "--",
        "-.", "---", ".--.", "--.-", ".-.", "...", "-", "..-", "...-", ".--", "-..-", "-.--", "--.."
    };
    private static final String[] DIGITS = {
        "-----", ".----", "..---", "...--", "....-", ".....", "-....", "--...", "---..", "----."
    };

    private RhythmParser() { }

    /** Converts any Unicode digits (including Persian and Arabic-Indic) to 0-9. */
    static String normalize(String s) {
        StringBuilder sb = new StringBuilder(s.length());
        for (int i = 0; i < s.length(); i++) {
            char ch = s.charAt(i);
            if (Character.isDigit(ch)) {
                sb.append((char) ('0' + Character.digit(ch, 10)));
            } else if (ch == '،' || ch == '؛') {
                sb.append(',');
            } else {
                sb.append(ch);
            }
        }
        return sb.toString();
    }

    /** Parses one whole number; accepts Persian and Arabic digits. */
    public static long parseNumber(String s) {
        if (s == null) {
            throw new IllegalArgumentException("Enter a number");
        }
        String n = normalize(s).trim();
        if (n.isEmpty()) {
            throw new IllegalArgumentException("Enter a number");
        }
        try {
            return Long.parseLong(n);
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("\"" + n + "\" is not a whole number");
        }
    }

    /**
     * Parses a rhythm. Numbers can be separated by spaces, commas or semicolons.
     * One number means an even blink (that long on, that long off). If the list ends
     * on an ON time, a pause is added so a repeat does not merge with the next ON.
     */
    public static long[] parse(String text) {
        if (text == null || text.trim().isEmpty()) {
            throw new IllegalArgumentException("Your rhythm is empty");
        }
        String[] parts = normalize(text).trim().split("[\\s,;]+");
        List<Long> list = new ArrayList<>();
        for (String p : parts) {
            if (p.isEmpty()) {
                continue;
            }
            long v;
            try {
                v = Long.parseLong(p);
            } catch (NumberFormatException e) {
                throw new IllegalArgumentException("\"" + p + "\" is not a number");
            }
            if (v < MIN_MS) {
                throw new IllegalArgumentException("Every time must be at least " + MIN_MS + " ms (got " + v + ")");
            }
            if (v > MAX_MS) {
                throw new IllegalArgumentException("Times can't be longer than one hour");
            }
            list.add(v);
        }
        if (list.isEmpty()) {
            throw new IllegalArgumentException("Your rhythm is empty");
        }
        if (list.size() > MAX_STEPS) {
            throw new IllegalArgumentException("Too many steps (max " + MAX_STEPS + ")");
        }
        if (list.size() == 1) {
            list.add(list.get(0));
        } else if (list.size() % 2 == 1) {
            long pause = 0;
            for (int i = 1; i < list.size(); i += 2) {
                pause = Math.max(pause, list.get(i));
            }
            list.add(pause);
        }
        return toArray(list);
    }

    public static String format(long[] steps) {
        StringBuilder sb = new StringBuilder();
        for (long s : steps) {
            if (sb.length() > 0) {
                sb.append(' ');
            }
            sb.append(s);
        }
        return sb.toString();
    }

    /**
     * Builds a rhythm from text in Morse code. Dot = 1 unit, dash = 3, gap inside a
     * letter = 1, between letters = 3, between words = 7. Ends with a 7-unit pause.
     * Characters other than letters, digits and spaces are skipped.
     */
    public static long[] fromMorse(String text, int unitMs) {
        if (unitMs < MIN_MS) {
            throw new IllegalArgumentException("Dot length must be at least " + MIN_MS + " ms");
        }
        if (unitMs * 7L > MAX_MS) {
            throw new IllegalArgumentException("Dot length is too long");
        }
        if (text == null) {
            throw new IllegalArgumentException("Type some letters or digits");
        }
        String up = text.toUpperCase(Locale.ROOT);
        List<Long> out = new ArrayList<>();
        boolean wordGap = false;
        boolean any = false;
        for (int i = 0; i < up.length(); i++) {
            char ch = up.charAt(i);
            String code;
            if (ch >= 'A' && ch <= 'Z') {
                code = LETTERS[ch - 'A'];
            } else if (ch >= '0' && ch <= '9') {
                code = DIGITS[ch - '0'];
            } else {
                if (Character.isWhitespace(ch) && any) {
                    wordGap = true;
                }
                continue;
            }
            if (any) {
                out.add((wordGap ? 7L : 3L) * unitMs);
            }
            wordGap = false;
            for (int s = 0; s < code.length(); s++) {
                if (s > 0) {
                    out.add((long) unitMs);
                }
                out.add((code.charAt(s) == '-' ? 3L : 1L) * unitMs);
            }
            any = true;
        }
        if (!any) {
            throw new IllegalArgumentException("Type some letters or digits");
        }
        out.add(7L * unitMs);
        if (out.size() > MAX_STEPS) {
            throw new IllegalArgumentException("That text is too long");
        }
        return toArray(out);
    }

    private static long[] toArray(List<Long> list) {
        long[] a = new long[list.size()];
        for (int i = 0; i < a.length; i++) {
            a[i] = list.get(i);
        }
        return a;
    }
}
