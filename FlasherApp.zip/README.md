# Flasher – flashlight strobe app for Android

Controls the phone's flashlight with:

- **Flasher tab** – set how long the light is ON and OFF (20 ms to 1 hour; sliders cover 20 ms to 5 s, or type any value). Changes apply live while it runs. Presets: Strobe, Fast, Blink, Slow, Beacon.
- **Rhythm tab** – your own pattern, as milliseconds alternating ON, OFF, ON, OFF… (e.g. `200 100 200 100 600 400`). Presets (SOS, Heartbeat, Burst, Double tap, Disco), **record a rhythm by tapping** a pad, or **type text and turn it into Morse code**.
- Repeat forever or stop automatically after N seconds.
- Keeps flashing with the screen off (foreground service, with a Stop button in the notification).
- No camera permission needed. Works on Android 8.0+.

Very fast flashing (under about 30 ms) depends on the phone: many phones can't switch the torch that quickly and will blur the timing.

**Warning:** fast flashing can trigger seizures in people with photosensitive epilepsy.

---

## Get the .apk (no computer needed)

This project builds the .apk in the cloud with GitHub Actions (free).

1. Make a free account at github.com and create a **new repository** (private is fine).
2. In the repository choose **Add file → Upload files** and upload the single file **`FlasherApp.zip`** (don't unzip it).
3. Choose **Add file → Create new file**. Type the name `.github/workflows/build-apk.yml` (typing the slashes makes the folders), paste the contents of the `build-apk.yml` file that came with the zip, and commit.
4. Open the **Actions** tab. A run called "Build Android APK" starts by itself (about 5 minutes). If it doesn't, open it and press **Run workflow**.
5. When it turns green, go to the repository's **Releases** (right-hand side of the main page). Download **Flasher.apk** from the newest release.
6. Open the file on your phone and allow "install unknown apps" when Android asks.

If the run turns red, open it, copy the red error text and send it to me; it's usually a one-line fix.

## Build it yourself instead

With Android Studio: **File → Open** this folder, wait for the sync, then **Build → Build APK(s)**.
With a terminal (JDK 17 and the Android SDK installed): `./gradlew assembleDebug`. The APK ends up in `app/build/outputs/apk/debug/app-debug.apk`.

## Code map

- `MainActivity.java` – the screen (tabs, sliders, rhythm editor, tap recorder, Morse)
- `FlashService.java` – the flashing engine and notification (runs with the screen off)
- `RhythmParser.java` – parses rhythm text, builds Morse rhythms
- `TimeScale.java` – logarithmic slider maths
